const smallCups = document.querySelectorAll('.cup-small')
const listers = document.getElementById('liters')
const percentage = document.getElementById('percentage')
const remained = document.getElementById('remained')

//we gonna declare the function twice once below when the application loads below

updateBigCup()


//NOTICE WE TOOK TWO VARIABLE WHILE ITERATING . ONE IS CUP VARIABLE 
//AND OTHER IS THE INDEX FOR IT
//THE REASON FOR ITERATING THROUGH CUPS IS TO PUT EVENT LISTENERS 
//ON EACH CUP

smallCups.forEach((cup,idx)=>{
        console.log(idx)
        cup.addEventListener('click',() =>highlightCups(idx))
})





function highlightCups(idx){
/*this below is system which when pressed any fullcup again it will empty it just so that 
if user mistakenly presses any cup and it is now showed full so user 
can press that cup again to make it empty */


/*so we do that by giving a condn that if the last cup which u last clicked is full
and the cup next to it is not full (or empty)

then we will decrease the index of that last filled cup and then show it empty and 
that we do by decreamenting the idx by idx--*/

/*one doubt is in next condn it reads if the nextelementsibling also contains full then decreament 
but its not poss when we already filled our cups how much we want the others suppsoed to be empty 

so i solved this doubt as i noticed it is written !smallcups so it negates or does the opposite of our cond so now 
the cond reads the nextelementsibling is supposed to be empty only then it will do the dcreament 
*/


    if(smallCups[idx].classList.contains('full')&& 
    !smallCups[idx].nextElementSibling.classList.contains('full'))
    {
        idx--
    }

    smallCups.forEach((cup,idx2)=>
    {
        if(idx2 <= idx){  //so this to check that the glass we clicked on has the index greater than prev cups . if so it should fill all other cups
            cup.classList.add('full')  //remember we made a css for full classes named .cup.cup-small.full
        }else{
            cup.classList.remove('full')
        }
    })

    //second declaration of func is below
    updateBigCup()


}

function updateBigCup(){
//first we will get no. of full glasses 
        const fullCups = document.querySelectorAll('.cup-small.full').length
        totalCups = smallCups.length

        console.log(fullCups)
        console.log(totalCups)

        if(fullCups ===0){
            percentage.style.visibility="hidden"
            percentage.style.height=0
        } else{
            percentage.style.visibility = 'visible'
            percentage.style.height=`${fullCups/totalCups*330}px`
            percentage.innerText = `${fullCups/totalCups * 100}
            %` //The innerText property sets or returns the text content of an element.




/*so above is system in which when cups clicked it will fill big cups 
so full cups variabe has data of small full cups length 

now we put it in situation that if full cups is 0 thn visibility should be 0 

else the more glass clicked it will increase height 

that is done 

      by dividin no. of small full cups by totall number of small cups and multiplied by height*/

        }

        //creating a system to remove remaining blank space in cup

        if(fullCups ===totalCups){

            remained.style.height=0;
            remained.style.visibility="hidden"
          

        }
}